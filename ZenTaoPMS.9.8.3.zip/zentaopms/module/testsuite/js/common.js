$(document).ready(function()
{
    if(typeof(flow) != 'undefined' && flow == 'onlyTest') toggleSearch();
})
