<?php
$lang->message->common  = '消息';
$lang->message->index   = '首頁';
$lang->message->setting = '設置';

$lang->message->typeList['mail']    = '郵件';
$lang->message->typeList['message'] = '瀏覽器通知';
$lang->message->typeList['webhook'] = 'Webhook';
