<?php
$lang->message->common  = '消息';
$lang->message->index   = '首页';
$lang->message->setting = '设置';

$lang->message->typeList['mail']    = '邮件';
$lang->message->typeList['message'] = '浏览器通知';
$lang->message->typeList['webhook'] = 'Webhook';
