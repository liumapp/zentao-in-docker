<?php
$lang->message->common  = 'Message';
$lang->message->index   = 'Index';
$lang->message->setting = 'Setting';

$lang->message->typeList['mail']    = 'Mail';
$lang->message->typeList['message'] = 'Browser notifications';
$lang->message->typeList['webhook'] = 'Webhook';
