$(document).ready(function()
{
    $("a.preview").modalTrigger({width:1000, type:'iframe'});
})
