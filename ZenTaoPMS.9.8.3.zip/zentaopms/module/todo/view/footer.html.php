<?php js::set('account', $app->user->account)?>
<?php include '../../common/view/footer.html.php';?>
