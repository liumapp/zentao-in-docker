$(document).ready(function()
{
    setTimeout(function(){fixedTheadOfList('#bugAssign')}, 100);
});
