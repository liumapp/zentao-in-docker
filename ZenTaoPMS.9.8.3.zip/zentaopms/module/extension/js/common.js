$(function()
{
    $("a.extension, a.manual").modalTrigger({width:1024, height:600, type:'iframe'});
})
